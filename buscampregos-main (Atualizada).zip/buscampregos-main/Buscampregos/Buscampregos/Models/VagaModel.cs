﻿namespace Buscampregos.Models
{
    public class VagaModel
    {
        public int Id { get; set; }
        public string Cargo { get; set; }
        public string Empresa { get; set; }

        public string Local { get; set; }
        public string TempoPostagem { get; set; }
        public string Periodo { get; set; }
    }
}
