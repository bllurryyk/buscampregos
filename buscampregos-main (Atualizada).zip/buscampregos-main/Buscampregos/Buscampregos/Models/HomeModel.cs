﻿namespace Buscampregos.Models
{
    public class HomeModel
    {
        public string NomeUser { get; set; }

        public string EmailUser { get; set; }
    }
}
